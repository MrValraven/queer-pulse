QUEERPULSE PRESS KIT
====================

All assets in this archive are released under a Creative Commons Attribution
4.0 (CC BY 4.0) licence for editorial use. For commercial use, write to
hello@queerpulse.com first.

CONTENTS
--------
queerpulse-mark.svg                  The mark, full colour, vector.
queerpulse-mark-1024.png                The mark, 1024 px, transparent.
queerpulse-mark-monochrome.svg       Single-colour mark, vector.
queerpulse-mark-monochrome-1024.png     Single-colour mark, 1024 px, transparent.
queerpulse-logo-primary.png          Wordmark for light grounds, 2048 px wide.
queerpulse-logo-inverse.png          Wordmark for dark grounds, 2048 px wide.
queerpulse-logo-coral.png            Wordmark on the coral field, 2048 px wide.
queerpulse-app-icon-512.png          The app icon as it ships on devices.
queerpulse-brand-colours.txt         The palette as hex and RGB.
queerpulse-brand-reference.pdf       Printable colour and typography reference.

USING THE MARKS
---------------
Leave one full P-height of clear space around the mark on every side. Minimum
size is 88 px wide on screen, 18 mm in print. The wordmark always carries the
coral pulse dot, except in the coral colourway, where the dot becomes plum.

The wordmark is set in Fraunces semibold with "Pulse" in the italic. Both
Fraunces and DM Sans are open source under the SIL Open Font License 1.1, so
the wordmark can be reset faithfully if you need it as outlines.

PRESS DESK
----------
hello@queerpulse.com
We respond within 48 hours. English and Portuguese.
